trainDataFile = load('trainDataXY.txt');
testDataFile = load('testDataXY.txt');

trainData = trainDataFile(2:end,:);
testData = testDataFile(2:end,:);

%creating an array of all class labels
training_label_vector = trainDataFile(1,:);
testing_label_vector = testDataFile(1,:);

% model = svmtrain(training_label_vector, training_instance_matrix [, 'libsvm_options']);
model = svmtrain(training_label_vector', trainData', '-c 1 -g 0.07 -b 1')
% [predicted_label, accuracy, decision_values/prob_estimates] = svmpredict(testing_label_vector, testing_instance_matrix, model [, 'libsvm_options']);
[predict_label, accuracy, prob_values] = svmpredict(testing_label_vector', testData', model, '-b 1');